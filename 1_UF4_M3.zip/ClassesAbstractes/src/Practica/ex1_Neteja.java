package Practica;


public class ex1_Neteja extends ex1_empleat {
	public ex1_Neteja(String Nom, String CiutatOrigen, String Lloc) {
		super(Nom, CiutatOrigen, Lloc);
		// TODO Auto-generated constructor stub
	
	@Override
	public double salariDiari() {
		// TODO Auto-generated method stub
		return 35.00;
	}

}
